title: 10_Java IO
date: '2019-11-26 15:39:38'
updated: '2019-11-26 15:39:38'
tags: [netty]
permalink: /articles/2019/11/26/1574753978730.html
---

## 流类

- ### 流的概念

  Java程序通过流来完成输入/输出。流是生产或消费信息的抽象。流通过Java的输入输出系统与物理设备链接。尽管与它们链接的物理设备不尽相同，所有的流行为具有同样的方式。这样，相同的输入/输出类和方法适用于所有类型的外部设备。这意味着一个输入流能抽象多种不同类型的输入，从磁盘文件，键盘或者网络套接字。同样一个输出流可以输出到控制台、磁盘文件或者相连的网络。流是处理输入/输出的一个洁净的方法，例如它不需要代码理解磁盘和网络的不同。Java中流的实现实在Java.io包定义的类层次结构内部。

- ### 输入/输出类

  - 在java io包中提供了60多个类（流）。
  - 在功能上分为两大类：输入流和输出流。
  - 从结构上又可以分为字节流（以字节为处理单位或者面向字节）和字符流（以字符为处理单位或者面向字符）。
  - 字节流的输入流和输出流基础是InputStream和OutputStream这两个抽象类，字节流的输入输出操作由这两个类的子类实现。字符流是Java 1.1版本后新增的以字符为单位进行输入输出的流，字符流输入输出的基础是抽象类Reader和Writer.

- ### 输入输出流概念

  - 输入输出时，数据在通信通道中流动，所谓数据流（Stream）指的是所有数据通信通道之中，数据的起点和终点。信息的通道就是一个数据流。只要输出据从一个地方流到另一个地方，这种数据流动的通道都可以称之为数据流。
  - 输入输出时相对于程序来说的，程序在使用数据时所扮演的角色有两个：一个是源，一个是目的。若程序是数据流的源，即数据提供者，这个数据流对程序来说就是一个输出流，若程序是数据的终点，这个数据流相对于程序来说是一个输入流。

- ### 字节流和字符流

  - Java的原始版本 1.0 是不包含字符流的，因此所有的输入和输出都是以字节为单位的。Java 1.1版本增加了 字符流的功能。
  - 需要声明：在最底层，所有的输入、输出都是字节形式的，基于字符的流只为处理字符提供方便有效的方法。

- ### 输入流

  读数据的逻辑为：open a stream -> while more information -> read information -> close the stream 

- ### 输出流

  写数据的逻辑为：open a stream - > while more information -> 	write information -> close the stream

- ### 流的分类

  - 节点流：从特定的地方读写的流类，例如：磁盘或一块内存区域
  - 过滤流：使用节点流作为输入输出，。过滤流是使用一个已经存在的输入流或者输出流创建的。

- ### InputStream

  InputStream包含一套字节输入流需要的方法，可以完成最基本的从输入流读取数据的功能。当Java程序需要外设的数据时，可根据数据的不同形式，创建一个适当的InputStream子类类型的对象来完成与该外设的连接，然后再调用这个流类对象的特定输入方法来实现对相应外设的输入操作。

  InputStream类子类对象自然也继承了InputStream类的方法，常用的方法有：读数据的方法read(),获取输入流字节数的方法avaliable(),定位输入位置指针的方法skip(),reset(),mark()等。

 ![inputStream.png](https://img.hacpai.com/file/2019/11/inputStream-1aef6031.png)


- ### OutputStream

  - 三个基本的写方法：abstract void write(int b) ：往输出流中写入一个字节。 void write(byte[] b)：往输出流中写入数组b中的所有字节。 void wirte(byte[] b,int off,int len):往输出流中写入数据组b中从偏移量off开始的len个字节的数据。	其它方法：void flush():刷新输出流，强制缓冲区中的输出字节被写出。void close（）：关闭输出流，释放和这个流相关的系统资源。

  - OutputStream 是定义了流式字节输出模式的抽象类。该类的所有方法返回一个void值并且在出错的情况下引发一个IOException异常。

   ![outputStream.png](https://img.hacpai.com/file/2019/11/outputStream-e1b6a131.png)


- ### 过滤流

  在InputStream和OutputStream的子类中，FilterInputStream和FilterOutputStream 过滤流抽象类中又派生出DataInputStream和DataOutPutStream 数据输入输出流类等子类。

  ![sreamconnection.png](https://img.hacpai.com/file/2019/11/sreamconnection-b6100ded.png)


- ### java IO库的设计原则

  - Java IO库提供了一个称作为链接的机制，可以将一个流与另一个流首位相连，形成一个流管道的链接，这种机制实际上是一种Decorator装饰设计模式的应用。
  - 通过流的链接可以动态增加流的功能，而这种功能的增加是通过组合一些流的功能而动态获取的。
  - 我们要获取一个IO对象，往往要产生多个IO对象，而装饰模式给我们提供了实现上的灵活性。

  ![reader.png](https://img.hacpai.com/file/2019/11/reader-ef1d7476.png)


  

![writer.png](https://img.hacpai.com/file/2019/11/writer-3a7f800c.png)

