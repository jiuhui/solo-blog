title: mysql查询一个表中不存在另一个表的数据
date: '2017-12-26 10:53:54'
updated: '2017-12-26 10:53:54'
tags: [数据库]
permalink: /articles/2017/12/26/1514256834000.html
---




```sql
SELECT * FROM A 
WHERE  id  NOT  IN  ( SELECT id FROM B);

或者
SELECT * FROM A 
WHERE 
    NOT  EXISTS  ( 
        SELECT 1 
        FROM B 
        WHERE B.id = A.id );

或者
SELECT 
  A.* 
FROM 
  A  LEFT JOIN B
    ON (A.id = B.id)
WHERE
  b.id  IS  NULL
```

最好用最后一种，可以分页
